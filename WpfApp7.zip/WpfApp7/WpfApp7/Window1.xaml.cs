﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp7
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            using (LessonEntities1 lessonEntities = new LessonEntities1())
            {
                var b = lessonEntities.FileUser.ToList();
                {

                }
                grid.ItemsSource = b;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog opendialog = new OpenFileDialog();
            opendialog.ShowDialog();
            FileInfo fn = new FileInfo(opendialog.FileName);
            fn.CopyTo(@"C: \Users\Александр\source\repos\WpfApp7\WpfApp7\bin\Debug\lol\" + opendialog.SafeFileName, true);
            string a = opendialog.SafeFileName;
            using (LessonEntities1 lessonEntities = new LessonEntities1())
            {
                FileUser fileuser = new FileUser()
                {
                    loginUser = idUser.id,
                    fileName = a,
                };
                lessonEntities.FileUser.Add(fileuser);
                lessonEntities.SaveChanges();
                var b = lessonEntities.FileUser.ToList();
                {

                }
                grid.ItemsSource = b;
            }
        }

        private void Grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            idUser.file = (grid.SelectedItem as FileUser).fileName;
            Window2 window2 = new Window2();
            window2.Show();
        }
    }
}
