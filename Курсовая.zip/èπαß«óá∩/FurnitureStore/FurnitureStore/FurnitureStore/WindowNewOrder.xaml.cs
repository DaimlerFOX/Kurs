﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FurnitureStore
{
    /// <summary>
    /// Логика взаимодействия для WindowNewOrder.xaml
    /// </summary>
    public partial class WindowNewOrder : Window
    {
        public WindowNewOrder()
        {
            InitializeComponent();
            ButtonNewOrder.Background = Brushes.LightSkyBlue;
            MaxHeight = SystemParameters.MaximizedPrimaryScreenHeight;
            MaxWidth = SystemParameters.MaximizedPrimaryScreenWidth;
            using (FurnitureStoreEntities furnitureStoreEntities = new FurnitureStoreEntities())
            {
                var user = furnitureStoreEntities.User.Where(k => k.id_User == idUser.id).FirstOrDefault();
                {

                }
                var name = user.Name_User;
                var surname = user.Surname_User;
                var middlename = user.Middlename_User;
                NameUser.Content = name;
                SurnameUser.Content = surname;
                MiddlenameUser.Content = middlename;
            }
        }
        private void ButtonOpenMenu_Click(object sender, RoutedEventArgs e)
        {
            GridMenu.Width = 220;
            ButtonHome.Visibility = Visibility.Visible;
            ButtonNewOrder.Visibility = Visibility.Visible;
            ButtonReverso.Visibility = Visibility.Visible;
            ButtonSetting.Visibility = Visibility.Visible;
            ButtonSoldFutniture.Visibility = Visibility.Visible;
            ButtonWarehouse.Visibility = Visibility.Visible;
            ButtonOpenMenu.Visibility = Visibility.Hidden;
            ButtonCloseMenu.Visibility = Visibility.Visible;
            NameUser.Visibility = Visibility.Visible;
            SurnameUser.Visibility = Visibility.Visible;
            MiddlenameUser.Visibility = Visibility.Visible;

        }
        //Закрытие меню
        private void ButtonCloseMenu_Click(object sender, RoutedEventArgs e)
        {
            GridMenu.Width = 60;
            ButtonHome.Visibility = Visibility.Hidden;
            ButtonNewOrder.Visibility = Visibility.Hidden;
            ButtonReverso.Visibility = Visibility.Hidden;
            ButtonSetting.Visibility = Visibility.Hidden;
            ButtonSoldFutniture.Visibility = Visibility.Hidden;
            ButtonWarehouse.Visibility = Visibility.Hidden;
            ButtonOpenMenu.Visibility = Visibility.Visible;
            ButtonCloseMenu.Visibility = Visibility.Hidden;
            NameUser.Visibility = Visibility.Hidden;
            SurnameUser.Visibility = Visibility.Hidden;
            MiddlenameUser.Visibility = Visibility.Hidden;
        }
        private void ButtonHome_Click(object sender, RoutedEventArgs e)
        {
            WindowStore windowStore = new WindowStore();
            windowStore.Show();
            this.Close();
        }

        private void ButtonSoldFutniture_Click(object sender, RoutedEventArgs e)
        {
            WindowSoldFurniture windowSoldFurniture = new WindowSoldFurniture();
            windowSoldFurniture.Show();
            this.Close();
        }

        private void ButtonSetting_Click(object sender, RoutedEventArgs e)
        {
            WindowSetting windowSetting = new WindowSetting();
            windowSetting.Show();
            this.Close();
        }

        private void ButtonReverso_Click(object sender, RoutedEventArgs e)
        {
            WindowReverso windowReverso = new WindowReverso();
            windowReverso.Show();
            this.Close();
        }

        private void ButtonWarehouse_Click(object sender, RoutedEventArgs e)
        {
            WindowWarehouse windowWarehouse = new WindowWarehouse();
            windowWarehouse.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
