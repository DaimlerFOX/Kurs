﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FurnitureStore
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //Изменение textbox LoginUser при наведении на него
        private void LoginUser_MouseEnter(object sender, MouseEventArgs e)
        {
            if (PasswordUser.Text == "")
            {
                PasswordUser.Text = "Password";
            }
            if (LoginUser.Text == "Login")
            {
                LoginUser.Text = "";
            }
        }
        //Изменение textbox PasswordUser при наведении на него
        private void PasswordUser_MouseEnter(object sender, MouseEventArgs e)
        {
            if (LoginUser.Text == "")
            {
                LoginUser.Text = "Login";
            }
            if (PasswordUser.Text == "Password")
            {
                PasswordUser.Text = "";
            }
        }
        //Авторизация
        private void WindowStoreOpen_Click(object sender, RoutedEventArgs e)
        {
            using (FurnitureStoreEntities context = new FurnitureStoreEntities())
            {
                var user = context.User.Where(k => (k.Login_User == LoginUser.Text) && (k.Password_User == PasswordUser.Text)).FirstOrDefault();
                {

                }
                if (user != null)
                {
                    idUser.id = user.id_User;
                    WindowStore windowStore = new WindowStore();
                    windowStore.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Пользователя нет");
                }
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
